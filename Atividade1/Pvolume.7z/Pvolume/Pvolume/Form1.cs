﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            double raio, altura;
            if (Double.TryParse(txtAltura.Text, out altura) &&
                double.TryParse(txtRaio.Text, out raio))
            {
                if ((altura <= 0) || (raio <= 0))
                {
                    MessageBox.Show("altura e raio deve ser maior que zero");
                    txtAltura.Focus();
                }
                else
                {
                    double volume;
                    volume = 3.14 * raio * raio * altura;
                    volume = Math.PI * Math.Pow(raio, 2) * altura;
                    txtVolume.Text = volume.ToString("N2");
                }


            }
            else
            {
                MessageBox.Show("valor invalido");
            }

        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = String.Empty;
            txtRaio.Focus();
        }
    }
}
